@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h4 style="color:rgba(0,0,0,.5)">Almacén/Articulos/Nuevo</h4>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors->all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
		</div>
	</div>
{!!Form::open(array('url'=>'almacen/articulo','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
{{Form::token()}}
<style>
    .marron {
    background-color: maroon;
    color: #ffffff;
    }
    .rojo {
    background-color: red;
    color: #ffffff;
    }
    
     .naranja{
    background-color: orange;
    color: #000000;
    }
    
    .amarillo{
    background-color: #FFFF00;
    color: #000000;
    }
    
    .dorado{
    background-color: #dfaf1f;
    color: #000000;
    }
    
    .olivo {
    background-color: olivedrab;
    color: #ffffff;
    }
  
    .purpura {
    background-color: blueviolet;
    color: #000000;
    }
    
     .blanco{
    background-color: cornsilk;
    color: #000000;
    }
    
    .verde{
    background-color: green;
    color: #000000;
    }
    
    .azul{
    background-color: blue;
    color: #000000;
    }
    
     .azul-marino{
    background-color: #445d84;
    color: #000000;
    }
    
    .aqua{
    background-color: aquamarine;
    color: #000000;
    }
    
    .teal{
    background-color: teal;
    color: #000000;
    }
    
    
     .gris{
    background-color: #444;
    color: #fff;
    }
    
     .plata{
    background-color: #8a9597;
    color: #fff;
    }
    .gray{
    background-color: gray;
    color: #fff; 
    }
      .negro{
    background-color: #222;
    color: #fff;
    }
    
.thumb{
     margin: 10px 10px 10px 10px;
    height: 150px;
    width: 150px;
}
    #imgSalida{
         margin: 10px 10px 10px 10px;
    height: 150px;
    width: 150px;
    }
    
     #imgSalida1{
         margin: 10px 10px 10px 10px;
    height: 150px;
    width: 150px;
    }
    
    #imgSalida2{
    margin: 10px 10px 10px 10px;
    height: 150px;
    width: 150px;
    }
    
     
    #imgSalida3{
    margin: 10px 10px 10px 10px;
    height: 150px;
    width: 150px;
    }
    
    #imgSalida4{
    margin: 10px 10px 10px 10px;
    height: 150px;
    width: 150px;
    }
    
    div#div_file{
       position: relative;
       padding: 10px;
       width: 200px;
        font-family:sans-serif;
    }
    
    input#file-input{
        position: absolute;
        top:0px;
        left: 0px;
        right: 0px;
        bottom: 0px;
        width: 100%;
        height: 100%;
        opacity: 0;
    }
    
       input#file-input1{
        position: absolute;
        top:0px;
        left: 0px;
        right: 0px;
        bottom: 0px;
        width: 100%;
        height: 100%;
        opacity: 0;
    }
    
        input#file-input2{
        position: absolute;
        top:0px;
        left: 0px;
        right: 0px;
        bottom: 0px;
        width: 100%;
        height: 100%;
        opacity: 0;
    }
    
        input#file-input3{
        position: absolute;
        top:0px;
        left: 0px;
        right: 0px;
        bottom: 0px;
        width: 100%;
        height: 100%;
        opacity: 0;
    }
    
        input#file-input4{
        position: absolute;
        top:0px;
        left: 0px;
        right: 0px;
        bottom: 0px;
        width: 100%;
        height: 100%;
        opacity: 0;
    }
    
    p#texto{
        text-align: center;
        color: #333; 
        
    }
    
</style>
<div class="row">
    <div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
        <div class="panel panel-default" style="border:1px solid rgba(0,0,0,.18);">
          <div class="panel-heading" style="background:#333; color:#fff;"><i class="fa fa-pencil"></i> Datos del articulo   </div>
          <div class="panel-body">
              <h6 style="color:#5cb85c">Los campos con (*) son obligatorios</h6>
                <label for="nombre"  style="font-size: small">Nombre</label>
            	<input type="text" name="nombre" class="form-control" placeholder="Autogenerado" disabled>
                <br>
            	<label for="nombre"  style="font-size: small">Código</label>
            	<input type="text" name="codigo" class="form-control" placeholder="Autogenerado" disabled>
                <br>
                <div class="row">
                    <div class="col-md-6">
                         <label for="nombre"  style="font-size: small">Categoría (*)</label>
                           <select name="idcategoria" class="form-control">
                                @foreach ($categorias as $cat)
                                   <option value="{{$cat->idcategoria}}">{{$cat->nombre}}</option>
                                   <!--La idea es q se almacene el varchar y no el id chaaa, en le show hay q tener cuidado para ello bueno hay q ver ingreso :d -->
                                @endforeach
                            </select>
                            
                            
                    </div>
                    
                     <div class="col-md-6">
                         <label for="nombre"  style="font-size: small">SubCategoría (*)</label>
                           <select name="idsubcategoria" class="form-control input-sm" id="select-subcategoria">
                               <option value="">-Seleccione Subcategoria-</option>
                                @foreach ($subcategorias as $subcat)
                                   <option value="{{$subcat->idsubcategoria}}">{{$subcat->nombre}}</option>
                                   <!--La idea es q se almacene el varchar y no el id chaaa, en le show hay q tener cuidado para ello bueno hay q ver ingreso :d -->
                                @endforeach
                            </select>
                    </div>
                </div>
                <br>
                 <div class="row">
                    <div class="col-md-6">
                         <label for="nombre"  style="font-size: small">Tipo(*)</label>
                           <select placeholder="aaa" name="tipo" class="form-control"  id="select-tipo">
                               <!--- @foreach ($tipos as $tip)
                                   <option value="{{$tip->nombre}}">{{$tip->nombre}}</option>
                                   <!--La idea es q se almacene el varchar y no el id chaaa, en le show hay q tener cuidado para ello bueno hay q ver ingreso :d 
                                @endforeach-->
                            </select>
                    </div>
                    
                     <div class="col-md-6">
                         <label for="nombre"  style="font-size: small">Marca(*)</label>
                           <select name="marca" class="form-control">
                                @foreach ($marcas as $mar)
                                   <option value="{{$mar->nombre}}">{{$mar->nombre}}</option>
                                @endforeach
                            </select>
                    </div>
                </div>
                <br>
                 <div class="row">
                    <div class="col-md-6">
                         <label for="nombre"  style="font-size: small">Material</label>
                           <select name="material" class="form-control" id="select-material">
                               <!-- <option value="-" selected>-Ninguno-</option>
                                
                               @foreach ($materiales as $mat)
                                   <option value="{{$mat->nombre}}">{{$mat->nombre}}</option>
                                   <!--La idea es q se almacene el varchar y no el id chaaa, en le show hay q tener cuidado para ello bueno hay q ver ingreso :d
                                @endforeach-->
                                
                            </select>
                    </div>
                    
                     <div class="col-md-6">
                         <label for="nombre" style="font-size: small">Talla</label>
                           <select name="talla" class="form-control" id="select-talla">
                              <!--  <option value="-" selected>-Ninguno-</option>
                                @foreach ($tallas as $tall)
                                   <option value="{{$tall->nombre}}">{{$tall->nombre}}</option>
                                   <!--La idea es q se almacene el varchar y no el id chaaa, en le show hay q tener cuidado para ello bueno hay q ver ingreso :d 
                                @endforeach-->
                            </select>
                    </div>
                    
                </div>
                <br>
                  <div class="row">
                      <div class="col-md-4 " >
                          <div class="row">
                             <div id="div_file">
                              <p id="texto"><i class="fa fa-file-image-o"></i> Imagen Principal</p>
                              <input type="file" id="file-input" name="imagen" />
                              <img id="imgSalida" src="" class="img-thumbnail"/>
                             </div>
                             
                          </div>
                          <div class="row">
                               <img id="img" src="{{asset('img/shop.png')}}"/ style="margin-left:8%;" height="90%" width="80%">
                          </div>
                          
                      </div>
                      
                       <div class="col-md-8">
                           <div class="row">
                               <div class="col-md-6">
                                  <div id="div_file">
                                      <p id="texto"><i class="fa fa-file-image-o"></i> Primera  Imagen</p>
                                      <input type="file" id="file-input1" name="imagen1" />
                                     <img id="imgSalida1" src="" class="img-thumbnail"/>
                                  </div>
                               </div>
                               
                               <div class="col-md-6">
                                   <div id="div_file">
                                      <p id="texto"><i class="fa fa-file-image-o"></i> Segunda Imagen</p>
                                      <input type="file" id="file-input2" name="imagen2" />
                                     <img id="imgSalida2" src="" class="img-thumbnail"/>
                                  </div>
                               </div>
                           </div>
                           <div class="row">
                               <div class="col-md-6">
                                  <div id="div_file">
                                      <p id="texto"><i class="fa fa-file-image-o"></i> Tercera Imagen</p>
                                      <input type="file" id="file-input3" name="imagen3" />
                                     <img id="imgSalida3" src="" class="img-thumbnail"/>
                                  </div>
                               </div>
                               
                               <div class="col-md-6">
                                   <div id="div_file">
                                      <p id="texto"><i class="fa fa-file-image-o"></i> Cuarta Imagen</p>
                                      <input type="file" id="file-input4" name="imagen4" />
                                     <img id="imgSalida4" src="" class="img-thumbnail"/>
                                  </div>
                               </div>
                           </div>
                      </div>
                      
                      
                  </div>
    
               
          </div>
        </div>
    </div>
    

     
      <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
        <div class="panel panel-default" style="border:1px solid rgba(0,0,0,.18);">
          <div class="panel-heading" style="background:#333;color:#fff;"><i class="fa fa-bookmark"></i> Precio-Stock </div>
          <div class="panel-body">
              <h6 style="color:#5cb85c">Los campos con (*) son obligatorios</h6>
              <div class="row">
                  <div class="col-md-12">
                        <label for="nombre" style="font-size: small">Precio de Venta (*)</label>
                         <div class="input-group">
                          <span class="input-group-addon">S/.</span>
                          <input  name="precio_venta" required value="{{old('precio_venta')}}" class="form-control">
                      </div>
                  </div>
              </div>
            <br>
            <div class="row">
                  <div class="col-md-6">
                        <label for="nombre" style="font-size: small">Cantidad por volumen </label>
                         <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                          <input  name="cantidad_volumen" value="{{old('cantidad_volumen')}}" class="form-control" type="number">
                      </div>
                  </div>
                   <div class="col-md-6">
                        <label for="nombre" style="font-size: small">Precio por volumen </label>
                         <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-money"></i></span>
                          <input  name="precio_mayor" value="{{old('precio_mayor')}}" class="form-control" type="number">
                      </div>
                  </div>
              </div>      
            <br>
           
                 <div class="row">
                  <div class="col-md-6">
                        <label for="nombre" style="font-size: small">Stock mínimo (*)</label>
                         <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-cart-arrow-down"></i></span>
                          <input  name="stockmin" value="{{old('stockmin')}}" class="form-control" type="number" >
                      </div>
                  </div>
                   <div class="col-md-6">
                        <label for="nombre" style="font-size: small">Stock inicial(*)</label>
                         <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-cart-plus"></i></span>
                          <input  name="stock" value="{{old('stock')}}" class="form-control" type="number">
                      </div>
                  </div>
                </div>  
               <br>
               
               
              </div>
          </div>
        </div>
        
          <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
        <div class="panel panel-default">
          <div class="panel-heading" style="background:#333;color:#fff;"><i class="fa fa-plus"></i> Más detalles </div>
          <div class="panel-body">
             
              <div class="row">
                  <div class="col-md-6">
                        <label for="nombre" style="font-size: small">Color</label>
                            <select name="color" class="form-control">
                                   <option value="-" selected>-Ninguno-</option>
                                   <option value="marron" class="marron">Marron</option>
                                   <option value="rojo" class="rojo">Rojo</option>
                                   <option value="naranja" class="naranja">Naranja</option>
                                   <option value="amarillo" class="amarillo">Amarillo</option>
                                   <option value="dorado" class="dorado">Dorado</option>
                                   <option value="olivo" class="olivo">Olivo</option>
                                   <option value="purpura" class="purpura">Purpura</option>
                                   <option value="blanco" class="blanco">Blanco</option>
                                   <option value="verde" class="verde">Verde</option>
                                   <option value="azul" class="azul">Azul</option>
                                   <option value="azul-marino" class="azul-marino">Azul-Marino</option>
                                   <option value="teal" class="teal">Teal</option>
                                   <option value="gris" class="gris">Gris</option>
                                   <option value="gris" class="plata">Plata</option>
                                   <option value="gray" class="gray">Gray</option>
                                   <option value="negro" class="negro">Negro</option>
                                   <option value="multicolor">-Multicolor-</option>
                                  
                            </select>
                  </div>
                  
                   <div class="col-md-6">
                        <label for="nombre" style="font-size: small">Edad</label>
                            <select name="edad" class="form-control">
                                   @foreach ($edades as $ed)
                                   <option value="{{$ed->nombre}}">{{$ed->nombre}}</option>
                                @endforeach
                            </select>

                  </div>
              </div>
            <br>
            <div class="row">
                  <div class="col-md-6">
                        <label for="nombre" style="font-size: small">Sexo </label>
                        <select name="sexo" class="form-control">
                                   <option value="-" selected>-Ninguno-</option>
                                   <option value="Unisex">Unisex</option>
                                   <option value="Hombre">Hombre</option>
                                   <option value="Mujer">Mujer</option>
                                   <option value="Niño">Niño</option>
                                   <option value="Niña">Niña</option>
                        </select>
                  </div>
                   <div class="col-md-6">
                        <label for="nombre"  style="font-size: small">Club</label>
                           <select name="club" class="form-control">
                                @foreach ($clubs as $cl)
                                   <option value="{{$cl->nombre}}">{{$cl->nombre}}</option>
                                   <!--La idea es q se almacene el varchar y no el id chaaa, en le show hay q tener cuidado para ello bueno hay q ver ingreso :d -->
                                @endforeach
                            </select>
                  </div>
              </div>
              <br>
            <div class="row">
                  <div class="col-md-12">
                        <label for="nombre" style="font-size: small">Nota</label>
                        <input  class="form-control" name="descripcion" rows="4" >
                  </div>
              </div>      
            <br>
                <div class="row">
                      <div class="col-md-6">
                         <div class="form-group">
                             <button type="submit" class="btn btn-default" style="background:#5cb85c;color:#fff;"> <span class="fa fa-floppy-o"> Guardar</span></button>
                             <button type="reset" class="btn btn-default" style="background:#777;color:#fff;"> <span class="fa fa-close"> Cancelar</span></button>
                        </div>
                           
                      </div>
                      
                  </div>  
              </div>
            </div>
        </div>
        
    </div>
</div>

{!!Form::close()!!}
@push ('scripts')
<script src="{{asset('js/JsBarcode.all.min.js')}}"></script>
<script src="{{asset('js/jquery.PrintArea.js')}}"></script>
<script src="{{asset('js/custom-file-input.js')}}"></script>
<script src="{{asset('js/jquery.custom-file-input.js')}}"></script>
 <script src="{{asset('js/jQuery-2.1.4.min.js')}}"></script>
  <script src="{{asset('js/tipo.js')}}"></script>

<script>
 /*   $('#idsubcategoria').on('change',function(event){
       console.log(event);
       var subcat_id=event.target.value;
        //ajax $.get('/ajax-tipo?subcat_id=' + subcat_id,function(data)
        $.get('/ajax-tipo?subcat_id=' + subcat_id,function(data){
            //success data
            console.log(data);
        });
       
    }); */
</script>
<script>
function generarBarcode()
{   
    codigo=$("#codigobar").val();
    JsBarcode("#barcode", codigo, {
    format: "EAN13",
    font: "OCRB",
    fontSize: 18,
    textMargin: 0
    });
}
$('#liAlmacen').addClass("treeview active");
$('#liArticulos').addClass("active");


//Código para imprimir el svg
function imprimir()
{
    $("#print").printArea();
}

</script>

  <script type="text/javascript" language="javascript">
$(window).load(function(){

 $(function() {
  $('#file-input').change(function(e) {
      addImage(e); 
     });

     function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;
    
      if (!file.type.match(imageType))
       return;
  
      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
     }
  
     function fileOnload(e) {
      var result=e.target.result;
      $('#imgSalida').attr("src",result);
     }
    });
    
    
    $(function() {
  $('#file-input1').change(function(e) {
      addImage(e); 
     });

     function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;
    
      if (!file.type.match(imageType))
       return;
  
      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
     }
  
     function fileOnload(e) {
      var result=e.target.result;
      $('#imgSalida1').attr("src",result);
     }
    });
    
      $(function() {
  $('#file-input2').change(function(e) {
      addImage(e); 
     });

     function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;
    
      if (!file.type.match(imageType))
       return;
  
      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
     }
  
     function fileOnload(e) {
      var result=e.target.result;
      $('#imgSalida2').attr("src",result);
     }
    });
    
     $(function() {
  $('#file-input3').change(function(e) {
      addImage(e); 
     });

     function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;
    
      if (!file.type.match(imageType))
       return;
  
      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
     }
  
     function fileOnload(e) {
      var result=e.target.result;
      $('#imgSalida3').attr("src",result);
     }
    });
    
     $(function() {
  $('#file-input4').change(function(e) {
      addImage(e); 
     });

     function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;
    
      if (!file.type.match(imageType))
       return;
  
      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
     }
  
     function fileOnload(e) {
      var result=e.target.result;
      $('#imgSalida4').attr("src",result);
     }
    });
  });


 
</script>
@endpush

@endsection