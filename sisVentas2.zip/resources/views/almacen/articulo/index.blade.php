@extends ('layouts.admin')
@section ('contenido')
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h4 style="color:#222">Listado de Artículos <a href="articulo/create"><button class="btn btn-default" style="border: 1px solid #337ab7;"><i class="fa fa-file-o"></i> Nuevo</button></a> <a href="{{url('reportearticulos')}}" target="_blank"><button class="btn btn-primary">Reporte</button></a></h4>
		@include('almacen.articulo.search')
		@include('almacen.partials.messages')
		<br>
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Nombre</th>
					<th>Código</th>
				    <th>Categoría</th>
					<th>P.Venta</th>
					<th>Stock</th>
					<th>Imagen</th>
					<th>Estado</th>
					<th>Opciones</th>
				</thead>
               @foreach ($articulos as $art)
               @if($art->stock==$art->stockmin)
				<tr class="danger">
					<td>{{ $art->idarticulo}}</td>
					<td>{{ $art->nombre}}</td>
					<td>{{ $art->codigo}}</td>
				    <td>{{ $art->categoria}}</td>
                    <td>{{ $art->precio_venta}}</td>			
                     <td>{{ $art->stock}}</td> 
					<td>
						<img src="{{asset('imagenes/articulos/'.$art->imagen)}}" alt="{{ $art->nombre}}" height="60px" width="60px" class="img-thumbnail">
					</td>
				
				    
				    @if ($art->estado=='Activo')
					<td><span class="label label-success">{{ $art->estado}}</span></td>
					@else
					<td><span class="label label-danger">{{ $art->estado}}</span></td>
					@endif
					<td>
						<a href="{{URL::action('ArticuloController@edit',$art->idarticulo)}}"><button class="btn btn-warning"  data-toggle="tooltip" data-placement="bottom" title="editar!"><i class="fa fa-edit"></i></button></a>
                     
                        <a href=""  data-target="#modal-show-{{$art->idarticulo}}" data-toggle="modal"><button class="btn btn-primary" data-toggle="tooltip" data-placement="bottom" title="detalles!"><i class="fa fa-newspaper-o"></i></button></a>

                        <a href=""  data-target="#modal-barras-{{$art->idarticulo}}" data-toggle="modal"><button class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Cod. barras!" ><i class="fa fa-barcode"></i></button></a>
                        
                         <a href="" data-target="#modal-delete-{{$art->idarticulo}}" data-toggle="modal"><button class="btn btn-danger" data-toggle="tooltip" data-placement="bottom" title="Inabilitar!"><i class="fa fa-close"></i></button></a>
					</td>
				</tr>
				@else
					<tr>
					<td>{{ $art->idarticulo}}</td>
					<td>{{ $art->nombre}}</td>
					<td>{{ $art->codigo}}</td>
				    <td>{{ $art->categoria}}</td>
                    <td>{{ $art->precio_venta}}</td>			
                    <td>{{ $art->stock}}</td>
					<td>
						<img src="{{asset('imagenes/articulos/'.$art->imagen)}}" alt="{{ $art->nombre}}" height="60px" width="60px" class="img-thumbnail">
					</td>
				
				    
				    @if ($art->estado=='Activo')
					<td><span class="label label-success">{{ $art->estado}}</span></td>
					@else
					<td><span class="label label-danger">{{ $art->estado}}</span></td>
					@endif
					<td>
					   <a href="{{URL::action('ArticuloController@edit',$art->idarticulo)}}"><button class="btn btn-warning"  data-toggle="tooltip" data-placement="bottom" title="editar!"><i class="fa fa-edit"></i></button></a>
                       
                        <a href=""  data-target="#modal-show-{{$art->idarticulo}}" data-toggle="modal"><button class="btn btn-primary" data-toggle="tooltip" data-placement="bottom" title="detalles!"><i class="fa fa-newspaper-o"></i></button></a>
                     
                        <a href=""  data-target="#modal-barras-{{$art->idarticulo}}" data-toggle="modal"><button class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Cod. barras!" ><i class="fa fa-barcode"></i></button></a>
                        
                         <a href="" data-target="#modal-delete-{{$art->idarticulo}}" data-toggle="modal"><button class="btn btn-danger" data-toggle="tooltip" data-placement="bottom" title="Inabilitar!"><i class="fa fa-close"></i></button></a>
					</td>
				</tr>
				@endif
				
				@include('almacen.articulo.modal',[$art->nombre])
				 <!--Modal-->
				@include('almacen.articulo.barras',[$art->nombre,$art->codigo])
				
				@include('almacen.articulo.show',[$art->nombre,$art->stock,$art->talla,$art->color,$art->precio_mayor,$art->cantidad_volumen,$art->stockmin,$art->edad,$art->descripcion,$art->imagen,$art->imagen1,$art->imagen2,$art->imagen3,$art->imagen4,$art->precio_venta])
				
				@endforeach
				
			</table>
		</div>
		{{$articulos->render()}}
	</div>
	
	


</div>
</div>
@push ('scripts')
<!---<script src="{{asset('js/custom-file-input.js')}}"></script>
<script src="{{asset('js/jquery-v1.min.js')}}"></script>-->
<script src="{{asset('js/JsBarcode.all.min.js')}}"></script>
<script>
$('#liAlmacen').addClass("treeview active");
$('#liArticulos').addClass("active");
    
</script>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
@endpush
@endsection