
    <div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="modal-show-{{$art->idarticulo}}">

	
	<div class="modal-dialog" style="width:50% !important;">
		<div class="modal-content" style="border-radius: 15px 15px 15px 15px;" >
			<div class="modal-header" style="background:#333; border-radius: 10px 10px 0px 0px;">
				<button type="button" class="close" data-dismiss="modal" 
				aria-label="Close">
                <span aria-hidden="true"><i class="fa fa-close" style="color:#fff"></i></span>
                </button>
                <h5 class="modal-title" style="color:#fff;"><span class="label label" style="color:#fff; background:#019299; font-size:12px;">Detalles de:</span><span style="color:#d9d6d8;"> {{ $art->nombre}}</span></h5>
                
			</div>
			<div class="modal-body" style="background:#f8f8f8; border-radius: 0px 0px 10px 10px; ">
<!--               -->
          
                 <div class="row" >
                  
                       <div class="col-md-4">
                        <label for="email"  style="color:#019299; font-size:14px;">Precio por mayor:</label>  <label for="email"  style=" color:#888" > {{ $art->precio_mayor}}</label>
                     
                    </div>
                    
                     <div class="col-md-4">
                      <label for="email"  style="color:#019299; font-size:14px;">Cantidad por mayor:</label>  <label for="email" style=" color:#888" > {{ $art->cantidad_volumen}}</label>
                    </div>
                    
                
                      
                    <div class="col-md-2">
                          <label for="email"  style="color:#019299; font-size:14px;">Stock :</label> <label for="email" style=" color:#888" > {{ $art->stock}}</label>
                     
                    </div>
                      
                        <div class="col-md-2">
                          <label for="email"  style="color:#019299; font-size:14px;">Stockmín:</label> <label for="email" style=" color:#888" > {{ $art->stockmin}}</label>
                     
                    </div>
                       
                 </div>
                       <hr style="color:#999;">
               

 
            <div class="row">
                 <div class="col-md-3"> <!--Inicio col-->
                <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Sexo:</label>  <label for="email"  style=" color:#888" > {{ $art->sexo}}</label>
                     
                    </div>
                  
                 </div>
                 
                  <br>
                  
                 <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Edad:</label>  <label for="email"  style=" color:#888" > {{ $art->edad}}</label>
                     
                    </div>
                   
                 </div>
                 
                  <br>
                 <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Talla:</label>  <label for="email"  style=" color:#888" > {{ $art->talla}}</label>
                     
                    </div>
                  
                 </div>
                  <br>
                 <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Color:</label>  <label for="email"  style=" color:#888" > {{ $art->color}}</label>
                     
                    </div>
                  </div> <!--Fin col -->
                    
                    <br>
                 <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Club:</label>  <label for="email"  style=" color:#888" > {{ $art->club}}</label>
                     
                    </div>
                  </div> <!--Fin col -->
                 </div>
                 
                <div class="col-md-9"> <!--Inicio col-->
                   <div class="row">
                        <div class="col-md-4"> <!--Inicio col-->
                           <div class="panel panel-default" style="margin-top:30%;">
                              <div class="panel-body">
                                   <span style="color:#333"></span><span class="label label" style="color:#fff; background:#5cb85c; font-size:12px;"> S/.{{ $art->precio_venta}}</span>
                                   <img src="{{asset('imagenes/articulos/'.$art->imagen)}}" alt="{{ $art->imagen}}" height="200px" width="120px" class="img-thumbnail">
                              </div>
                              <div class="panel-footer">Imagen Principal</div>
                            </div>
                        </div>
                        
                        <div class="col-md-8"> <!--Inicio col-->
                           <div class="row">
                              <div class="col-md-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body">
                                        <img src="{{asset('imagenes/articulos/'.$art->imagen1)}}" alt="{{ $art->imagen1}}" height="200px" width="120px" class="img-thumbnail">
                                      </div>
                                   
                                    </div>
                              </div>
                               
                               <div class="col-md-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body">
                                           <img src="{{asset('imagenes/articulos/'.$art->imagen2)}}" alt="{{ $art->imagen2}}" height="200px" width="120px" class="img-thumbnail">
                                      </div>
                                    </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body">
                                          <img src="{{asset('imagenes/articulos/'.$art->imagen3)}}" alt="{{ $art->imagen3}}" height="200px" width="120px" class="img-thumbnail">
                                      </div>
                                         
                                    </div>
                              </div>
                               
                               <div class="col-md-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body">
                                           <img src="{{asset('imagenes/articulos/'.$art->imagen4)}}" alt="{{ $art->imagen4}}" height="200px" width="120px" class="img-thumbnail">
                                      </div>
                                         
                                    </div>
                              </div>
                           </div>
                        </div>
                        
                       
                    
                       
                   </div>
                   
                   <div class="row">
                       <div class="col-md-12">
                           <p style="color:#666"><span class="label label" style="color:#fff; background:#019299; font-size:12px;">Nota:</span> {{$art->descripcion}}</p>
                       </div>
                   </div>
                 </div>

            </div>      
           
			</div> <!--final del body--->
   
		</div>
	</div>

<style>
  

 
</style>

<script>

</script>







