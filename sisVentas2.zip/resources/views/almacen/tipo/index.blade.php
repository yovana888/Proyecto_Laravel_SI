@extends ('layouts.admin')
@section ('contenido')
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	     @include('almacen.tipo.create',$subcategorias)
		      <h4 style="color:#222">Listado de Tipos <a href=""  data-target="#modal-create" data-toggle="modal"><button class="btn btn-default" data-toggle="tooltip" data-placement="bottom" title="nuevo" >Nuevo</button></a> <a href="{{url('reportecategorias')}}" target="_blank"><button class="btn btn-primary">Reporte</button></a></h4>
		@include('almacen.talla.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Nombre</th>
					<th>Subcategoría</th>
					<th>Estado</th>
					<th>Opciones</th>
				</thead>
               @foreach ($tipos as $tip)
				<tr>
					<td>{{ $tip->idtipo}}</td>
					<td>{{ $tip->nombre}}</td>
					<td>{{ $tip->subcategoria}}</td>
                   
                    @if ($tip->estado=='Activo')
					<td><span class="label label-success">{{ $tip->estado}}</span></td>
					@else
					<td><span class="label label-danger">{{ $tip->estado}}</span></td>
					@endif
					
					<td>
					<!--	<a href="{{URL::action('TipoController@edit',$tip->idtipo)}}"><button class="btn btn-warning"><i class="fa fa-edit"></i></button></a>-->
                         <a href=""  data-target="#modal-edit-{{$tip->idtipo}}" data-toggle="modal"><button class="btn btn-warning" data-toggle="tooltip" data-placement="bottom" title="Editar" ><i class="fa fa-edit"></i></button></a>
                         
                         <a href="" data-target="#modal-delete-{{$tip->idtipo}}" data-toggle="modal"><button class="btn btn-danger" data-toggle="tooltip" data-placement="bottom" title="Inabilitar"><i class="fa fa-close"></i></button></a>
					</td>
				</tr>
				@include('almacen.tipo.edit',[$tip->nombre,$tip->subcategoria,$tip,$subcategorias])
				@include('almacen.tipo.modal')
				@endforeach
			</table>
		</div>
		{{$tipos->render()}}
	</div>
</div>
@push ('scripts')
<script>
$('#liAlmacen').addClass("treeview active");
$('#liTipo').addClass("active");
</script>
@endpush
@endsection