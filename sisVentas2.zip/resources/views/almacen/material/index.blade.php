@extends ('layouts.admin')
@section ('contenido')
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		 @include('almacen.material.create',$subcategorias)
		      <h4 style="color:#222">Listado de Materiales <a href=""  data-target="#modal-create" data-toggle="modal"><button class="btn btn-default" data-toggle="tooltip" data-placement="bottom" title="nuevo" >Nuevo</button></a> <a href="{{url('reportecategorias')}}" target="_blank"><button class="btn btn-primary">Reporte</button></a></h4>
		@include('almacen.material.search')
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Nombre</th>
					<th>Subcategoría</th>
					<th>Estado</th>
					<th>Opciones</th>
				</thead>
               @foreach ($materiales as $mat)
				<tr>
					<td>{{ $mat->idmaterial}}</td>
					<td>{{ $mat->nombre}}</td>
					<td>{{ $mat->subcategoria}}</td>
                   
                    @if ($mat->estado=='Activo')
					<td><span class="label label-success">{{ $mat->estado}}</span></td>
					@else
					<td><span class="label label-danger">{{ $mat->estado}}</span></td>
					@endif
					
					<td>
				<!--		<a href="{{URL::action('MaterialController@edit',$mat->idmaterial)}}"><button class="btn btn-warning"><i class="fa fa-edit"></i></button></a>-->
                        <a href=""  data-target="#modal-edit-{{$mat->idmaterial}}" data-toggle="modal"><button class="btn btn-warning" data-toggle="tooltip" data-placement="bottom" title="editar" ><i class="fa fa-edit"></i></button></a>
                        
                         <a href="" data-target="#modal-delete-{{$mat->idmaterial}}" data-toggle="modal"><button class="btn btn-danger"><i class="fa fa-close"></i></button></a>
					</td>
				</tr>
				
				@include('almacen.material.edit',[$mat->nombre,$mat->subcategoria,$mat,$subcategorias])
				@include('almacen.material.modal')
				@endforeach
			</table>
		</div>
		{{$materiales->render()}}
	</div>
</div>
@push ('scripts')
<script>
$('#liAlmacen').addClass("treeview active");
$('#liMaterial').addClass("active");
</script>
@endpush
@endsection