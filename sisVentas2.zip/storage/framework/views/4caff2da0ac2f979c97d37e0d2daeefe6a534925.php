<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Acerca de...</h3>
	</div>
</div>

<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<table>
	<!---	<tr><th>Jefe proyecto:</th><td>Ing. Juan Carlos Arcila Díaz</td></tr>
		<tr><th>Email:</th><td>jcarlos.ad7@gmail.com</td></tr>
		<tr><th>Whatsapp:</th><td>+51 931742904</td></tr>
		<tr><th>Facebook:</th><td><a href="www.facebook.com/jcarlosad7" target="_blank">www.facebook.com/jcarlosad7</a></td></tr>
		<tr><th>Empresa Responsable:</th><td>Solucciones Innovadoras Perú S.A.C</td></tr>
		<tr><th>Página web:</th><td><a href="www.incanatoit.com" target="_blank">www.incanatoit.com</a></td></tr>
		<tr><th>Otros proyectos:</th><td><a href="www.incanatoit.com/p/tienda.html" target="_blank">www.incanatoit.com/p/tienda.html</a></td></tr>-->
	</table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>