<?php $__env->startSection('contenido'); ?>
<div class="row">
	   <?php echo $__env->make('almacen.talla.create',$subcategorias, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		      <h4 style="color:#222">Listado de Tallas <a href=""  data-target="#modal-create" data-toggle="modal"><button class="btn btn-default" data-toggle="tooltip" data-placement="bottom" title="nuevo" >Nuevo</button></a> <a href="<?php echo e(url('reportecategorias')); ?>" target="_blank"><button class="btn btn-primary">Reporte</button></a></h4>
		<?php echo $__env->make('almacen.talla.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Nombre</th>
					<th>Subcategoría</th>
					<th>Estado</th>
					<th>Opciones</th>
				</thead>
               <?php foreach($tallas as $tall): ?>
				<tr>
					<td><?php echo e($tall->idtalla); ?></td>
					<td><?php echo e($tall->nombre); ?></td>
					<td><?php echo e($tall->subcategoria); ?></td>
                   
                    <?php if($tall->estado=='Activo'): ?>
					<td><span class="label label-success"><?php echo e($tall->estado); ?></span></td>
					<?php else: ?>
					<td><span class="label label-danger"><?php echo e($tall->estado); ?></span></td>
					<?php endif; ?>
					
					<td>
					<!--	<a href="<?php echo e(URL::action('TallaController@edit',$tall->idtalla)); ?>"><button class="btn btn-warning"><i class="fa fa-edit"></i></button></a>-->
                           <a href=""  data-target="#modal-edit-<?php echo e($tall->idtalla); ?>" data-toggle="modal"><button class="btn btn-warning" data-toggle="tooltip" data-placement="bottom" title="editar" ><i class="fa fa-edit"></i></button></a>
                           
                         <a href="" data-target="#modal-delete-<?php echo e($tall->idtalla); ?>" data-toggle="modal"><button class="btn btn-danger"><i class="fa fa-close"></i></button></a>
					</td>
				</tr>
				<?php echo $__env->make('almacen.talla.edit',[$tall->nombre,$tall->subcategoria,$tall,$subcategorias], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('almacen.talla.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; ?>
			</table>
		</div>
		<?php echo e($tallas->render()); ?>

	</div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
$('#liAlmacen').addClass("treeview active");
$('#liTalla').addClass("active");
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>