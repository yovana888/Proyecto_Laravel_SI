
    <div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="modal-show-<?php echo e($art->idarticulo); ?>">

	
	<div class="modal-dialog" style="width:50% !important;">
		<div class="modal-content" style="border-radius: 15px 15px 15px 15px;" >
			<div class="modal-header" style="background:#333; border-radius: 10px 10px 0px 0px;">
				<button type="button" class="close" data-dismiss="modal" 
				aria-label="Close">
                <span aria-hidden="true"><i class="fa fa-close" style="color:#fff"></i></span>
                </button>
                <h5 class="modal-title" style="color:#fff;"><span class="label label" style="color:#fff; background:#019299; font-size:12px;">Detalles de:</span><span style="color:#d9d6d8;"> <?php echo e($art->nombre); ?></span></h5>
                
			</div>
			<div class="modal-body" style="background:#f8f8f8; border-radius: 0px 0px 10px 10px; ">
<!--               -->
          
                 <div class="row" >
                  
                       <div class="col-md-4">
                        <label for="email"  style="color:#019299; font-size:14px;">Precio por mayor:</label>  <label for="email"  style=" color:#888" > <?php echo e($art->precio_mayor); ?></label>
                     
                    </div>
                    
                     <div class="col-md-4">
                      <label for="email"  style="color:#019299; font-size:14px;">Cantidad por mayor:</label>  <label for="email" style=" color:#888" > <?php echo e($art->cantidad_volumen); ?></label>
                    </div>
                    
                
                      
                    <div class="col-md-2">
                          <label for="email"  style="color:#019299; font-size:14px;">Stock :</label> <label for="email" style=" color:#888" > <?php echo e($art->stock); ?></label>
                     
                    </div>
                      
                        <div class="col-md-2">
                          <label for="email"  style="color:#019299; font-size:14px;">Stockmín:</label> <label for="email" style=" color:#888" > <?php echo e($art->stockmin); ?></label>
                     
                    </div>
                       
                 </div>
                       <hr style="color:#999;">
               

 
            <div class="row">
                 <div class="col-md-3"> <!--Inicio col-->
                <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Sexo:</label>  <label for="email"  style=" color:#888" > <?php echo e($art->sexo); ?></label>
                     
                    </div>
                  
                 </div>
                 
                  <br>
                  
                 <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Edad:</label>  <label for="email"  style=" color:#888" > <?php echo e($art->edad); ?></label>
                     
                    </div>
                   
                 </div>
                 
                  <br>
                 <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Talla:</label>  <label for="email"  style=" color:#888" > <?php echo e($art->talla); ?></label>
                     
                    </div>
                  
                 </div>
                  <br>
                 <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Color:</label>  <label for="email"  style=" color:#888" > <?php echo e($art->color); ?></label>
                     
                    </div>
                  </div> <!--Fin col -->
                    
                    <br>
                 <div class="row">
                   <div class="col-md-3">
                        <label for="email"  style="color:#019299; font-size:14px;">Club:</label>  <label for="email"  style=" color:#888" > <?php echo e($art->club); ?></label>
                     
                    </div>
                  </div> <!--Fin col -->
                 </div>
                 
                <div class="col-md-9"> <!--Inicio col-->
                   <div class="row">
                        <div class="col-md-4"> <!--Inicio col-->
                           <div class="panel panel-default" style="margin-top:30%;">
                              <div class="panel-body">
                                   <span style="color:#333"></span><span class="label label" style="color:#fff; background:#5cb85c; font-size:12px;"> S/.<?php echo e($art->precio_venta); ?></span>
                                   <img src="<?php echo e(asset('imagenes/articulos/'.$art->imagen)); ?>" alt="<?php echo e($art->imagen); ?>" height="200px" width="120px" class="img-thumbnail">
                              </div>
                              <div class="panel-footer">Imagen Principal</div>
                            </div>
                        </div>
                        
                        <div class="col-md-8"> <!--Inicio col-->
                           <div class="row">
                              <div class="col-md-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body">
                                        <img src="<?php echo e(asset('imagenes/articulos/'.$art->imagen1)); ?>" alt="<?php echo e($art->imagen1); ?>" height="200px" width="120px" class="img-thumbnail">
                                      </div>
                                   
                                    </div>
                              </div>
                               
                               <div class="col-md-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body">
                                           <img src="<?php echo e(asset('imagenes/articulos/'.$art->imagen2)); ?>" alt="<?php echo e($art->imagen2); ?>" height="200px" width="120px" class="img-thumbnail">
                                      </div>
                                    </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body">
                                          <img src="<?php echo e(asset('imagenes/articulos/'.$art->imagen3)); ?>" alt="<?php echo e($art->imagen3); ?>" height="200px" width="120px" class="img-thumbnail">
                                      </div>
                                         
                                    </div>
                              </div>
                               
                               <div class="col-md-6">
                                  <div class="panel panel-default">
                                      <div class="panel-body">
                                           <img src="<?php echo e(asset('imagenes/articulos/'.$art->imagen4)); ?>" alt="<?php echo e($art->imagen4); ?>" height="200px" width="120px" class="img-thumbnail">
                                      </div>
                                         
                                    </div>
                              </div>
                           </div>
                        </div>
                        
                       
                    
                       
                   </div>
                   
                   <div class="row">
                       <div class="col-md-12">
                           <p style="color:#666"><span class="label label" style="color:#fff; background:#019299; font-size:12px;">Nota:</span> <?php echo e($art->descripcion); ?></p>
                       </div>
                   </div>
                 </div>

            </div>      
           
			</div> <!--final del body--->
   
		</div>
	</div>

<style>
  

 
</style>

<script>

</script>







