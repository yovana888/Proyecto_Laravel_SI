<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h4 style="color:#222">Listado de Artículos <a href="articulo/create"><button class="btn btn-default" style="border: 1px solid #337ab7;"><i class="fa fa-file-o"></i> Nuevo</button></a> <a href="<?php echo e(url('reportearticulos')); ?>" target="_blank"><button class="btn btn-primary">Reporte</button></a></h4>
		<?php echo $__env->make('almacen.articulo.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('almacen.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<br>
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Nombre</th>
					<th>Código</th>
				    <th>Categoría</th>
					<th>P.Venta</th>
					<th>Stock</th>
					<th>Imagen</th>
					<th>Estado</th>
					<th>Opciones</th>
				</thead>
               <?php foreach($articulos as $art): ?>
               <?php if($art->stock==$art->stockmin): ?>
				<tr class="danger">
					<td><?php echo e($art->idarticulo); ?></td>
					<td><?php echo e($art->nombre); ?></td>
					<td><?php echo e($art->codigo); ?></td>
				    <td><?php echo e($art->categoria); ?></td>
                    <td><?php echo e($art->precio_venta); ?></td>			
                     <td><?php echo e($art->stock); ?></td> 
					<td>
						<img src="<?php echo e(asset('imagenes/articulos/'.$art->imagen)); ?>" alt="<?php echo e($art->nombre); ?>" height="60px" width="60px" class="img-thumbnail">
					</td>
				
				    
				    <?php if($art->estado=='Activo'): ?>
					<td><span class="label label-success"><?php echo e($art->estado); ?></span></td>
					<?php else: ?>
					<td><span class="label label-danger"><?php echo e($art->estado); ?></span></td>
					<?php endif; ?>
					<td>
						<a href="<?php echo e(URL::action('ArticuloController@edit',$art->idarticulo)); ?>"><button class="btn btn-warning"  data-toggle="tooltip" data-placement="bottom" title="editar!"><i class="fa fa-edit"></i></button></a>
                     
                        <a href=""  data-target="#modal-show-<?php echo e($art->idarticulo); ?>" data-toggle="modal"><button class="btn btn-primary" data-toggle="tooltip" data-placement="bottom" title="detalles!"><i class="fa fa-newspaper-o"></i></button></a>

                        <a href=""  data-target="#modal-barras-<?php echo e($art->idarticulo); ?>" data-toggle="modal"><button class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Cod. barras!" ><i class="fa fa-barcode"></i></button></a>
                        
                         <a href="" data-target="#modal-delete-<?php echo e($art->idarticulo); ?>" data-toggle="modal"><button class="btn btn-danger" data-toggle="tooltip" data-placement="bottom" title="Inabilitar!"><i class="fa fa-close"></i></button></a>
					</td>
				</tr>
				<?php else: ?>
					<tr>
					<td><?php echo e($art->idarticulo); ?></td>
					<td><?php echo e($art->nombre); ?></td>
					<td><?php echo e($art->codigo); ?></td>
				    <td><?php echo e($art->categoria); ?></td>
                    <td><?php echo e($art->precio_venta); ?></td>			
                    <td><?php echo e($art->stock); ?></td>
					<td>
						<img src="<?php echo e(asset('imagenes/articulos/'.$art->imagen)); ?>" alt="<?php echo e($art->nombre); ?>" height="60px" width="60px" class="img-thumbnail">
					</td>
				
				    
				    <?php if($art->estado=='Activo'): ?>
					<td><span class="label label-success"><?php echo e($art->estado); ?></span></td>
					<?php else: ?>
					<td><span class="label label-danger"><?php echo e($art->estado); ?></span></td>
					<?php endif; ?>
					<td>
					   <a href="<?php echo e(URL::action('ArticuloController@edit',$art->idarticulo)); ?>"><button class="btn btn-warning"  data-toggle="tooltip" data-placement="bottom" title="editar!"><i class="fa fa-edit"></i></button></a>
                       
                        <a href=""  data-target="#modal-show-<?php echo e($art->idarticulo); ?>" data-toggle="modal"><button class="btn btn-primary" data-toggle="tooltip" data-placement="bottom" title="detalles!"><i class="fa fa-newspaper-o"></i></button></a>
                     
                        <a href=""  data-target="#modal-barras-<?php echo e($art->idarticulo); ?>" data-toggle="modal"><button class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Cod. barras!" ><i class="fa fa-barcode"></i></button></a>
                        
                         <a href="" data-target="#modal-delete-<?php echo e($art->idarticulo); ?>" data-toggle="modal"><button class="btn btn-danger" data-toggle="tooltip" data-placement="bottom" title="Inabilitar!"><i class="fa fa-close"></i></button></a>
					</td>
				</tr>
				<?php endif; ?>
				
				<?php echo $__env->make('almacen.articulo.modal',[$art->nombre], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				 <!--Modal-->
				<?php echo $__env->make('almacen.articulo.barras',[$art->nombre,$art->codigo], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				
				<?php echo $__env->make('almacen.articulo.show',[$art->nombre,$art->stock,$art->talla,$art->color,$art->precio_mayor,$art->cantidad_volumen,$art->stockmin,$art->edad,$art->descripcion,$art->imagen,$art->imagen1,$art->imagen2,$art->imagen3,$art->imagen4,$art->precio_venta], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				
				<?php endforeach; ?>
				
			</table>
		</div>
		<?php echo e($articulos->render()); ?>

	</div>
	
	


</div>
</div>
<?php $__env->startPush('scripts'); ?>
<!---<script src="<?php echo e(asset('js/custom-file-input.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-v1.min.js')); ?>"></script>-->
<script src="<?php echo e(asset('js/JsBarcode.all.min.js')); ?>"></script>
<script>
$('#liAlmacen').addClass("treeview active");
$('#liArticulos').addClass("active");
    
</script>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>