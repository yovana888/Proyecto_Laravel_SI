<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	     <?php echo $__env->make('almacen.subcategoria.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		  <h4 style="color:#222">Listado de Subcategorías <a href=""  data-target="#modal-create" data-toggle="modal"><button class="btn btn-default" data-toggle="tooltip" data-placement="bottom" title="nuevo" >Nuevo</button></a> <a href="<?php echo e(url('reportecategorias')); ?>" target="_blank"><button class="btn btn-primary">Reporte</button></a></h4>
		<?php echo $__env->make('almacen.subcategoria.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Id</th>
					<th>Nombre</th>
					<th>Estado</th>
					<th>Opciones</th>
				</thead>
               <?php foreach($subcategorias as $subcat): ?>
				<tr>
					<td><?php echo e($subcat->idsubcategoria); ?></td>
					<td><?php echo e($subcat->nombre); ?></td>
				    <?php if($subcat->estado=='Activo'): ?>
					<td><span class="label label-success"><?php echo e($subcat->estado); ?></span></td>
					<?php else: ?>
					<td><span class="label label-danger"><?php echo e($subcat->estado); ?></span></td>
					<?php endif; ?>
					<td>
					<!--	<a href="<?php echo e(URL::action('SubcategoriaController@edit',$subcat->idsubcategoria)); ?>"><button class="btn btn-warning"><i class="fa fa-edit"></i></button></a>-->
                           <a href=""  data-target="#modal-edit-<?php echo e($subcat->idsubcategoria); ?>" data-toggle="modal"><button class="btn btn-warning" data-toggle="tooltip" data-placement="bottom" title="editar" ><i class="fa fa-edit"></i></button></a>
                           
                         <a href="" data-target="#modal-delete-<?php echo e($subcat->idsubcategoria); ?>" data-toggle="modal" data-toggle="tooltip" data-placement="bottom" title="Inabilitar"><button class="btn btn-danger"><i class="fa fa-close"></i></button></a>
					</td>
				</tr>
				<?php echo $__env->make('almacen.subcategoria.edit',[$subcat->nombre,$subcat], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('almacen.subcategoria.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; ?>
			</table>
		</div>
		<?php echo e($subcategorias->render()); ?>

	</div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
$('#liAlmacen').addClass("treeview active");
$('#liSubcategorias').addClass("active");
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>