<?php

namespace sisVentas\Http\Requests;
use sisVentas\Http\Requests\Request;

class ArticuloFormRequest extends Request
{

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'idcategoria'=>'required',
            'stock'=>'required|numeric',
            'descripcion'=>'max:512',
            'imagen'=>'mimes:jpeg,bmp,png',
            'idsubcategoria'=>'required',
            'sexo'=>'max:9',
            'color'=>'max:20',
            'marca'=>'max:100',
            'club'=>'max:100',
            'edad'=>'max:80',
            'stockmin'=>'required|numeric',
            'imagen1'=>'mimes:jpeg,bmp,png',
            'imagen2'=>'mimes:jpeg,bmp,png',
            'imagen3'=>'mimes:jpeg,bmp,png',
            'imagen4'=>'mimes:jpeg,bmp,png',
            'tipo'=>'required|max:50',
            'talla'=>'max:30',
            'material'=>'max:40',
            'precio_venta'=>'required|numeric', //dafault 0
            'cantidad_volumen'=>'numeric', //no tan obligatorio pq no todos se venden así
            'precio_mayor'=>'numeric'
          
        ];
    }
}
