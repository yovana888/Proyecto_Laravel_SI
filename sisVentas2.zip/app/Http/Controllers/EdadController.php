<?php

namespace sisVentas\Http\Controllers;

use Illuminate\Http\Request;
use sisVentas\Http\Requests;
use sisVentas\Edad;
use Illuminate\Support\Facades\Redirect;
use sisVentas\Http\Requests\EdadFormRequest;
use DB;


class EdadController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request)
    {
        if ($request)
        {
            $query=trim($request->get('searchText'));
            $edades=DB::table('edad')->where('nombre','LIKE','%'.$query.'%')
            ->orderBy('idedad','desc')
            ->paginate(7);
            return view('almacen.edad.index',["edades"=>$edades,"searchText"=>$query]);
        }
    }
    public function create()
    {
        return view("almacen.edad.create");
    }
    public function store (EdadFormRequest $request)
    {
        $edad=new Edad;
        $edad->nombre=$request->get('nombre');
        $edad->estado='Activo';
        $edad->save();
        return Redirect::to('almacen/edad');

    }
    public function show($id)
    {
        return view("almacen.edad.show",["edad"=>Edad::findOrFail($id)]);
    }
    public function edit($id)
    {
        return view("almacen.edad.edit",["edad"=>Edad::findOrFail($id)]);
    }
    public function update(EdadFormRequest $request,$id)
    {
        $edad=Edad::findOrFail($id);
        $edad->nombre=$request->get('nombre');
        $edad->estado=$request->get('estado'); //si solo si ha sido desactivado si es asi pordra activarlo
        $edad->update();
        return Redirect::to('almacen/edad');
    }
    public function destroy($id)
    {
        $edad=Edad::findOrFail($id);
        $edad->estado='Inactivo';
        $edad->update();
        return Redirect::to('almacen/edad');
    }
}
