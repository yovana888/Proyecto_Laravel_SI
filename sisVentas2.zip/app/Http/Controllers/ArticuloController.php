<?php

namespace sisVentas\Http\Controllers;

use Illuminate\Http\Request;

use sisVentas\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use sisVentas\Http\Requests\ArticuloFormRequest;
use sisVentas\Http\Requests\TipoFormRequest;
use sisVentas\Articulo;
use sisVentas\Tipo;
use DB;
use Session;

use Fpdf;


class ArticuloController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request)
    {
        if ($request)
        {
            $query=trim($request->get('searchText'));
            
             $articulos=DB::table('articulo as a')
                ->join('categoria as c','a.idcategoria','=','c.idcategoria')
                ->join('subcategoria as sc','a.idsubcategoria','=','sc.idsubcategoria')
                ->select('a.idarticulo','a.nombre','a.codigo','a.stock','c.nombre as categoria','a.stock','a.precio_venta','a.imagen','a.estado','a.stockmin','sc.nombre as subcategoria','a.precio_mayor','a.cantidad_volumen','a.club','a.marca','a.talla','a.tipo','a.material','a.imagen1','a.imagen2','a.imagen3','a.imagen4','a.edad','a.color','a.sexo','a.descripcion')
                ->where('a.nombre','LIKE','%'.$query.'%')
                ->orwhere('a.codigo','LIKE','%'.$query.'%')
                ->orderBy('a.idarticulo','desc')
                ->paginate(7);
            return view('almacen.articulo.index',["articulos"=>$articulos,"searchText"=>$query]);
        }
        
      
    }
    public function create()
    {
         $categorias=DB::table('categoria')->where('condicion','=','1')->get();
         $subcategorias=DB::table('subcategoria')->where('estado','=','Activo')->get();
         $tipos=DB::table('tipo')->where('estado','=','Activo')->get();
         $marcas=DB::table('marca')->where('estado','=','Activo')->get();
         $edades=DB::table('edad')->where('estado','=','Activo')->get();
         $materiales=DB::table('material')->where('estado','=','Activo')->get();
         $tallas=DB::table('talla')->where('estado','=','Activo')->get();
         $clubs=DB::table('club')->where('estado','=','Activo')->get();
         
        return view("almacen.articulo.create",["categorias"=>$categorias,"subcategorias"=>$subcategorias,"tipos"=>$tipos,"marcas"=>$marcas,"materiales"=>$materiales,"tallas"=>$tallas,"clubs"=>$clubs,"edades"=>$edades]);
        
    }
    
    public function gettipos(TipoFormRequest $request, $id){
        //el id sera enviado por la ruta
        if($request->ajax()){ //si la peticion es asi retornamos una respuesta
            $tipos=Tipo::tipos($id);
            
            return response()->json($tipos);
            
        }
        
    }
    public function store (ArticuloFormRequest $request )
    {
        $articulo=new Articulo;
        //son Id es decir el valor a almacenarse son numeros
        $articulo->idcategoria=$request->get('idcategoria');
        $articulo->idsubcategoria=$request->get('idsubcategoria');
        
        //normal
        $articulo->marca=$request->get('marca'); 
        $articulo->tipo=$request->get('tipo');
        $articulo->material=$request->get('material');
        $articulo->talla=$request->get('talla');
        $articulo->club=$request->get('club');
        
        //los siguientes no vienen de una tabla si no que se llenaran directo del select como predeterminados por el programador.
        
        $articulo->sexo=$request->get('sexo');
        $articulo->edad=$request->get('edad');
        $articulo->color=$request->get('color');
        
        //llenable por usuario
        $articulo->descripcion=$request->get('descripcion');
        $articulo->stock=$request->get('stock');
        $articulo->stockmin=$request->get('stockmin');
        $articulo->precio_venta=$request->get('precio_venta');
        $articulo->cantidad_volumen=$request->get('cantidad_volumen');
        $articulo->precio_mayor=$request->get('precio_mayor');
        $articulo->estado='Activo';
       // $articulo->nombre=$request->get('nombre'); Autogenerado
        
        
        
        $number=DB::table('articulo')
        ->select(DB::raw('MAX(idarticulo)+1 as g'))->first();
        
        $aaa=$number->g;
       // implode($array_equipo)
        $long_num=strlen($aaa);
        $cont=0;
        $base=0;
        //cantidad de ceros a completar
        $cant_0_r=5-$long_num;
        $digitos=0;
        if($aaa==100000){
              
            Flash::danger("Ya no se puede autogenerar más numeros: Tope 99999 para articulos, Comunicarse con los desarroladores yovana.otaku@gmail.com o vaya a soporte tecnico");
            return view('almacen.articulo.index');

        }
        else {
            while($cont < $cant_0_r-1) 
            {
                
                $digitos=$digitos . $base;
                $cont++;
            }
        }
        
        $num_articulo=$digitos . $aaa;
        
        $articulo->codigo='8410420' . $num_articulo;
        
        //concatenado y sera almacenado en conj. en uno solo
        //para ello dare nombres distintos porque yolo, problema los q son id
        //ejemplo
        /*$cad1 = "aprender  a";
          $cad2 = "  programar";
          $cadt = $cad1 . $cad2;*/
        //$usuarios = DB::table('usuarios')->where('sexo', '=', 'M')->get();
        //Por ello usare la BD :s funcionara ? 1er intento, no funciono ahora separado las tablas y se llenara directo. 
                
        $nom1=$request->get('tipo');
        $nom2=$request->get('marca');
        $nom3=$request->get('material');
        $nom8=$request->get('club');
        $nom4=$request->get('sexo');
        $nom5=$request->get('talla');
        $nom6=$num_articulo;
        $nom7=$request->get('color');
        
        $nom_concat= $nom1. " " .$nom2. " " .$nom3. " " .$nom8. " " .$nom4. " " .$nom5 . $nom6 . "/" .$nom7; 
        $articulo->nombre=$nom_concat;
        

        if (Input::hasFile('imagen')){
        	$file=Input::file('imagen');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen=$file->getClientOriginalName();
        }
        
        if (Input::hasFile('imagen1')){
        	$file=Input::file('imagen1');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen1=$file->getClientOriginalName();
        }
        
         if (Input::hasFile('imagen2')){
        	$file=Input::file('imagen2');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen2=$file->getClientOriginalName();
        }
        
         if (Input::hasFile('imagen3')){
        	$file=Input::file('imagen3');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen3=$file->getClientOriginalName();
        }
        
        if (Input::hasFile('imagen4')){
        	$file=Input::file('imagen4');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen4=$file->getClientOriginalName();
        }
        
        
        $articulo->save();
     //   Session::flash('save','Se ha creado correctamente el nuevo articulo');
        return Redirect::to('almacen/articulo');

    }
    public function show($id)
    {
        //como se penso es similar a detalles en la tabla ingresos, hay q ver eso
        //return view("almacen.articulo.show",["articulo"=>Articulo::findOrFail($id)]);
        $articulo=DB::table('articulo as a')
            ->join('categoria as c','a.idcategoria','=','c.idcategoria')
            ->join('subcategoria as sc','a.idsubcategoria','=','sc.idsubcategoria')
            ->select('a.nombre','a.codigo','a.nombre','c.nombre as nom_cat','sc.nombre as nom_subcat','a.imagen','a.imagen1','a.imagen2','a.imagen3','a.imagen4','a.stokmin','a.color','a.sexo','a.edad','a.tipo','a.material','a.talla','a.descripcion','a.marca','a.club')
            ->where('a.idarticulo','=',$id)
            ->get();

   //  return Redirect::to('almacen/articulo',["articulo"=>$articulo]);
        return view("almacen.articulo.show",["articulo"=>$articulo]);
       
    }
    public function edit($id) //similar al create
    {
         $articulo=Articulo::findOrFail($id);
      
         $categorias=DB::table('categoria')->where('condicion','=','1')->get();
         $subcategorias=DB::table('subcategoria')->where('estado','=','Activo')->get();
         $tipos=DB::table('tipo')->where('estado','=','Activo')->get();
         $marcas=DB::table('marca')->where('estado','=','Activo')->get();
         $clubs=DB::table('club')->where('estado','=','Activo')->get();
         $materiales=DB::table('material')->where('estado','=','Activo')->get();
         $tallas=DB::table('talla')->where('estado','=','Activo')->get();
         $edades=DB::table('edad')->where('estado','=','Activo')->get();
        
         return view("almacen.articulo.edit",["articulo"=>$articulo,"categorias"=>$categorias,"subcategorias"=>$subcategorias,"marcas"=>$marcas,"tipos"=>$tipos,"clubs"=>$clubs,"materiales"=>$materiales,"tallas"=>$tallas,"edades"=>$edades]);
        
        
    }
    
    
    public function update(ArticuloFormRequest $request,$id)
    {
        $articulo=Articulo::findOrFail($id);

        //lo mismo que create
        $articulo->idcategoria=$request->get('idcategoria');
        $articulo->idsubcategoria=$request->get('idsubcategoria');
        $articulo->club=$request->get('club');
        $articulo->marca=$request->get('marca'); 
        $articulo->tipo=$request->get('tipo');
        $articulo->material=$request->get('material');
        $articulo->talla=$request->get('talla');
        $articulo->sexo=$request->get('sexo');
        $articulo->edad=$request->get('edad');
        $articulo->color=$request->get('color');
        $articulo->descripcion=$request->get('descripcion');
        $articulo->stock=$request->get('stock');
        $articulo->stockmin=$request->get('stockmin');
        $articulo->precio_venta=$request->get('precio_venta');
        $articulo->cantidad_volumen=$request->get('cantidad_volumen');
        $articulo->precio_mayor=$request->get('precio_mayor');
        $articulo->estado=$request->get('estado');
        
        
        ///generando codigo a concatenar ///////////////
        
        $aaa=$id;
       // implode($array_equipo)
        $long_num=strlen($aaa);
        $cont=0;
        $base=0;
        //cantidad de ceros a completar
        $cant_0_r=5-$long_num;
        $digitos=0;
        if($aaa==100000){
              
            Flash::danger("Ya no se puede autogenerar más numeros: Tope 99999 para articulos, Comunicarse con los desarroladores yovana.otaku@gmail.com o vaya a soporte tecnico");
            return view('almacen.articulo.index');

        }
        else {
            while($cont < $cant_0_r-1) 
            {
                
                $digitos=$digitos . $base;
                $cont++;
            }
        }
        
        $num_articulo=$digitos . $aaa;
        
        $articulo->codigo='8410420' . $num_articulo;
        
        //////////////////////////////////////////////////////////
        
        
        
        
        //Puede q se cambie los selec entonces el nombre debe cambiar
        $nom1=$request->get('tipo');
        $nom2=$request->get('marca');
        $nom3=$request->get('material');
        $nom8=$request->get('club');
        $nom4=$request->get('sexo');
        $nom5=$request->get('talla');
      //  $nom6=$request->get('codigo');
        $nom6=$num_articulo;
        $nom7=$request->get('color');
        
        $nom_concat= $nom1. " " .$nom2. " " .$nom3. " " .$nom8. " " .$nom4. " " .$nom5 . $nom6 . "/" .$nom7; 
        $articulo->nombre=$nom_concat;
        
        
        //el codigo no es editable, pero si se cargara :D
           
        //Imagenes

        if (Input::hasFile('imagen')){
        	$file=Input::file('imagen');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen=$file->getClientOriginalName();
        }
        
        if (Input::hasFile('imagen1')){
        	$file=Input::file('imagen1');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen1=$file->getClientOriginalName();
        }
        
         if (Input::hasFile('imagen2')){
        	$file=Input::file('imagen2');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen2=$file->getClientOriginalName();
        }
        
         if (Input::hasFile('imagen3')){
        	$file=Input::file('imagen3');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen3=$file->getClientOriginalName();
        }
        
        if (Input::hasFile('imagen4')){
        	$file=Input::file('imagen4');
        	$file->move(public_path().'/imagenes/articulos/',$file->getClientOriginalName());
            $articulo->imagen4=$file->getClientOriginalName();
        }
        

        $articulo->update();
     //   Session::flash('update','Se ha actualizado correctamente el articulo');
        return Redirect::to('almacen/articulo');
    }
    public function destroy($id)
    {
        $articulo=Articulo::findOrFail($id);
        $articulo->estado='Inactivo';
        $articulo->update();
        Session::flash('update','Se ha actualizado correctamente el estado del articulo');
        return Redirect::to('almacen/articulo');
    }
    
      public function barras($id)
    {
           //como se penso es similar a detalles en la tabla ingresos, hay q ver eso
        //return view("almacen.articulo.show",["articulo"=>Articulo::findOrFail($id)]);
        $articulo=DB::table('articulo as a')
            ->join('categoria as c','a.idcategoria','=','c.idcategoria')
            ->join('subcategoria as sc','a.idsubcategoria','=','sc.idsubcategoria')
            ->select('a.nombre','a.codigo','a.nombre','c.nombre as nom_cat','sc.nombre as nom_subcat','a.imagen','a.imagen1','a.imagen2','a.imagen3','a.imagen4','a.stokmin','a.color','a.sexo','a.edad','a.tipo','a.material','a.talla','a.descripcion','a.marca','a.club')
            ->where('a.idarticulo','=',$id)
            ->get();

   //  return Redirect::to('almacen/articulo',["articulo"=>$articulo]);
        return view("almacen.articulo.barras",["articulo"=>$articulo]);
    }
    public function reporte(){
         //Obtenemos los registros
         $registros=DB::table('articulo as a')
            ->join('categoria as c','a.idcategoria','=','c.idcategoria')
            ->select('a.idarticulo','a.nombre','a.codigo','a.stock','c.nombre as categoria','a.descripcion','a.imagen','a.estado')
            ->orderBy('a.nombre','asc')
            ->get();

         $pdf = new Fpdf();
         $pdf::AddPage();
         $pdf::SetTextColor(35,56,113);
         $pdf::SetFont('Arial','B',11);
         $pdf::Cell(0,10,utf8_decode("Listado Artículos"),0,"","C");
         $pdf::Ln();
         $pdf::Ln();
         $pdf::SetTextColor(0,0,0);  // Establece el color del texto 
         $pdf::SetFillColor(206, 246, 245); // establece el color del fondo de la celda 
         $pdf::SetFont('Arial','B',10); 
         //El ancho de las columnas debe de sumar promedio 190        
         $pdf::cell(30,8,utf8_decode("Código"),1,"","L",true);
         $pdf::cell(80,8,utf8_decode("Nombre"),1,"","L",true);
         $pdf::cell(65,8,utf8_decode("Categoría"),1,"","L",true);
         $pdf::cell(15,8,utf8_decode("Stock"),1,"","L",true);
         
         $pdf::Ln();
         $pdf::SetTextColor(0,0,0);  // Establece el color del texto 
         $pdf::SetFillColor(255, 255, 255); // establece el color del fondo de la celda
         $pdf::SetFont("Arial","",9);
         
         foreach ($registros as $reg)
         {
            $pdf::cell(30,6,utf8_decode($reg->codigo),1,"","L",true);
            $pdf::cell(80,6,utf8_decode($reg->nombre),1,"","L",true);
            $pdf::cell(65,6,utf8_decode($reg->categoria),1,"","L",true);
            $pdf::cell(15,6,utf8_decode($reg->stock),1,"","L",true);
            $pdf::Ln(); 
         }

         $pdf::Output();
         exit;
    }

}
