<?php

namespace sisVentas\Http\Controllers;

use Illuminate\Http\Request;
use sisVentas\Http\Requests;
use sisVentas\Subcategoria;
use Illuminate\Support\Facades\Redirect;
use sisVentas\Http\Requests\SubcategoriaFormRequest;
use DB;

class SubcategoriaController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request)
    {
        if ($request)
        {
            $query=trim($request->get('searchText'));
            $subcategorias=DB::table('subcategoria')->where('nombre','LIKE','%'.$query.'%')
            ->orderBy('idsubcategoria','desc')
            ->paginate(7);
            return view('almacen.subcategoria.index',["subcategorias"=>$subcategorias,"searchText"=>$query]);
        }
    }
    public function create()
    {
        return view("almacen.subcategoria.create");
    }
    public function store (SubcategoriaFormRequest $request)
    {
        $subcategoria=new Subcategoria;
        $subcategoria->nombre=$request->get('nombre');
        $subcategoria->estado='Activo';
        $subcategoria->save();
        return Redirect::to('almacen/subcategoria');

    }
    public function show($id)
    {
        return view("almacen.subcategoria.show",["subcategoria"=>Subcategoria::findOrFail($id)]);
    }
    public function edit($id)
    {
        return view("almacen.subcategoria.edit",["subcategoria"=>Subcategoria::findOrFail($id)]);
    }
    public function update(SubcategoriaFormRequest $request,$id)
    {
        $subcategoria=Subcategoria::findOrFail($id);
        $subcategoria->nombre=$request->get('nombre');
        $subcategoria->estado=$request->get('estado'); //si solo si ha sido desactivado si es asi pordra activarlo
        $subcategoria->update();
        return Redirect::to('almacen/subcategoria');
    }
    public function destroy($id)
    {
        $subcategoria=Subcategoria::findOrFail($id);
        $subcategoria->estado='Inactivo';
        $subcategoria->update();
        return Redirect::to('almacen/subcategoria');
    }
}
