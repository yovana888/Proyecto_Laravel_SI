<?php
namespace sisVentas;
use Illuminate\Database\Eloquent\Model;

class Articulo extends Model
{
    protected $table='articulo';

    protected $primaryKey='idarticulo';

    public $timestamps=false;


    protected $fillable =[
    	'idcategoria',
    	'codigo',
    	'nombre',
    	'stock',
    	'descripcion',
    	'imagen',
    	'estado',
        'idsubcategoria',
        'sexo',
        'color',
        'marca',
        'edad',
        'stockmin',
        'imagen1',
        'imagen2',
        'imagen3',
        'imagen4',
        'tipo',
        'talla',//este se jalara de la tabla tipo de acuerdo al filtrado anidado de los select, claro se almacenara como texto
        'material',
        'precio_venta',
        'cantidad_volumen',
        'precio_mayor'
        
    ];

    protected $guarded =[

    ];
}
